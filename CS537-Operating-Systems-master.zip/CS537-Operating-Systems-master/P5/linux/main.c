#include <stdio.h>



int
main(int argc, char *argv[])
{
    fd = open();
    pwrite(fd, buffer, size, offset);

    return 0;
}


