#ifndef _STRUCTDEF_H_
#define _STRUCTDEF_H_

// define struc for lock and cv
typedef struct{
  uint locked;
}lock_t;

typedef struct{           
  int head;           
  int tail;             
  int size;
  int queue[8];
  uint locked;            
}cond_t;


#endif //_STRUCTDEF_H_

