#include "types.h"
#include "stat.h"
#include "fcntl.h"
#include "user.h"
#include "x86.h"
#include "structDef.h"

void
lock_init(lock_t *lc) {
  lc->locked = 0;
}

void 
cond_init(cond_t *cv) {
  for(int i = 0; i < 8; i++){
    cv->queue[i] = 0;
  }
  cv->head = 0;
  cv->tail = 0;
  cv->size = 0;
  cv->locked = 0;
}

int
thread_create(void(*st_r)(void*), void *temp_arg) {
  void *stk = malloc(4096);
  if(stk == NULL)
    return -1;
  else
    return clone(st_r, temp_arg, stk);

  return -1;
}

void
cond_wait(cond_t *cv, lock_t *lc) {
  condsleep(cv, lc);
}

void
cond_signal(cond_t *cv) {
  condwake(cv);
}

int
thread_join() {
  void *stk = NULL;
  int pid = join(&stk);
  if(pid != -1)
    free(stk);
  return pid;
}

void
lock_acquire(lock_t *lc) {
  while(xchg(&lc->locked, 1) != 0)
    ;
}

void
lock_release(lock_t *lc) {
  xchg(&lc->locked, 0);
}
