#ifndef _CV_H_
#define _CV_H_

// cond_t struct definition.

typedef struct{
  volatile int queue[8]; // Store the pid of waiting threads.
  uint locked;            // Use to protect the queue.
  int head;              // Head of the queue.
  int rear;              // Rear of the queue.
  int size;              // Number of elements in the queue.
}cond_t;

// lock_t struct definition.

typedef struct{
  uint locked;
}lock_t;

#endif //_CV_H_

