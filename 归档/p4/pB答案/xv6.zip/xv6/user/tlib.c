#include "types.h"
#include "stat.h"
#include "fcntl.h"
#include "user.h"
#include "x86.h"
#include "cv.h"
#define PGSIZE 4096

int
thread_create(void(*start_routine)(void*), void *arg)
{
  void *stack = malloc(PGSIZE);
  if(stack == NULL)
    return -1;
  return clone(start_routine, arg, stack);
}

int
thread_join()
{
  // Retrive the starting address of stack allocated to the thread.
  void *stack = NULL;
  int pid = join(&stack);
  // Free the memory block allocated to the thread.
  if(pid != -1)
    free(stack);
  return pid;
}

void
lock_init(lock_t *lock)
{
  lock->locked = 0;
}

void
lock_acquire(lock_t *lock)
{
  // Spin lock.
  // Return old value of locked and store 1 in locked at the same time.
  while(xchg(&lock->locked, 1) != 0)
    ;
}

void
lock_release(lock_t *lock)
{
  xchg(&lock->locked, 0);
}

/**
 * Initialize the condition variable.
 */
void 
cond_init(cond_t *chan)
{
  for(int i = 0; i < 8; i++){
    chan->queue[i] = 0;
  }
  chan->locked = 0;
  chan->head = 0;
  chan->rear = 0;
  chan->size = 0;
}

void
cond_wait(cond_t *chan, lock_t *lock)
{
  condsleep(chan, lock);
}

void
cond_signal(cond_t *chan)
{
  condwake(chan);
}
